#include <Arduino.h>

int lampu = 26;
int lampu2 = 33;

void setup() {

    pinMode(lampu, OUTPUT);
    pinMode(lampu2, OUTPUT);
}

void loop() {

    digitalWrite(lampu, HIGH);
    digitalWrite(lampu2, HIGH);
    

    
    delay(1000); // Tunggu 1 detik

    // Matikan kedua LED
    digitalWrite(lampu, LOW);
    digitalWrite(lampu2, LOW);
    

    delay(1000);
}
