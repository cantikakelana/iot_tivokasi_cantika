void setup() {
  // put your setup code here, to run once
  Serial.begin(115200);
  Serial.println("Hello, ESP32");

  pinMode(16, OUTPUT); //lampu merah
  pinMode(17, OUTPUT); // lampu kuning
  pinMode(0, OUTPUT); // lampu hijau
}

void loop() { // lampu merah menyala selama 5 detik
  digitalWrite(16, HIGH);
  delay(5000); 
  digitalWrite(16, LOW);

  digitalWrite(17, HIGH); //lampu kuning menyala selama 3 detik
  delay(3000);
  digitalWrite(17, LOW);

  digitalWrite(0, HIGH); // lampu hijau menyala selama 6 detik
  delay(6000); // 
  digitalWrite(0, LOW);
}